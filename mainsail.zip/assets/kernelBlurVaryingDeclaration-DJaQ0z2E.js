import{S as e}from"./Viewer-C0MSWJtN.js";const r="kernelBlurVaryingDeclaration",a="varying vec2 sampleCoord{X};";e.IncludesShadersStore[r]||(e.IncludesShadersStore[r]=a);
